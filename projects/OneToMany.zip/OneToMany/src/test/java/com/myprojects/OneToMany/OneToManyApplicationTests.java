package com.myprojects.OneToMany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OneToManyApplicationTests {

	@Test
	void contextLoads() {
	}

}
