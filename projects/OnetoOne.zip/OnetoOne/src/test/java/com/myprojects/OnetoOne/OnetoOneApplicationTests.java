package com.myprojects.OnetoOne;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnetoOneApplicationTests {

	@Test
	void contextLoads() {
	}

}
