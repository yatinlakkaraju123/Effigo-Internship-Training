package com.myprojects.OnetoOne;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnetoOneApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnetoOneApplication.class, args);
	}

}
