package com.myprojects.JDBC_learning;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcLearningApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcLearningApplication.class, args);
	}

}
