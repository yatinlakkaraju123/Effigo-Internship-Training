package com.myprojects.JDBC_learning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcLearningApplicationTests {

	@Test
	void contextLoads() {
	}

}
