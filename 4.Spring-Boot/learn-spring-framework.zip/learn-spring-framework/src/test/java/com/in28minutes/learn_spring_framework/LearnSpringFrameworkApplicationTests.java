package com.in28minutes.learn_spring_framework;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringFrameworkApplicationTests {

	@Test
	void contextLoads() {
	}

}
