package com.in28minutes.learn_gradle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnGradleApplicationTests {

	@Test
	void contextLoads() {
	}

}
