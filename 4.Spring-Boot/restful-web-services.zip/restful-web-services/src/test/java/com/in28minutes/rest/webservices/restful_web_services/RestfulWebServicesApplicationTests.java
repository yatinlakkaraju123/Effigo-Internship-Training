package com.in28minutes.rest.webservices.restful_web_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulWebServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
